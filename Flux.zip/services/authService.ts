
import { User, AuthError, VerificationSession, PaymentProviderConfig, UserProfile, NotificationSettings, SecuritySettings, UserSession } from '../types';
import { emailService } from './emailService';
import { cryptoService } from './cryptoService';
import { API_BASE } from '../apiConfig';
import { db } from '@/database';
import { trackingService } from './trackingService';

const API_URL = `${API_BASE}/api/auth`;
const API_USERS = `${API_BASE}/api/users`;

export const authService = {
  isValidEmail: (email: string) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  },

  storeFacebookLoginId: (fbId: string) => {
      if (fbId) localStorage.setItem('_fb_login_id', fbId);
  },

  syncRemoteUsers: async () => {
      const currentUserEmail = authService.getCurrentUserEmail();
      try {
          const response = await fetch(`${API_USERS}/sync`);
          if (response.ok) {
              const data = await response.json();
              if (data && Array.isArray(data.users)) {
                  data.users.forEach((user: User) => {
                      if (currentUserEmail && user.email === currentUserEmail) return;
                      db.users.set(user);
                  });
              }
          }
      } catch (e) { console.warn("⚠️ [Sync] Failed to sync remote users."); }
  },

  performLoginSync: async (user: User) => {
      const { groupService } = await import('./groupService');
      const { chatService } = await import('./chatService');
      db.users.set(user);
      localStorage.setItem('cached_user_profile', JSON.stringify(user));
      await groupService.fetchGroups();
      await chatService.syncChats();
      authService.syncRemoteUsers();
  },

  login: async (email: string, password: string): Promise<{ user: User; nextStep: string }> => {
    try {
        const normalizedEmail = email.toLowerCase().trim();
        const hashedPassword = await cryptoService.hashPassword(password);
        const response = await fetch(`${API_URL}/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email: normalizedEmail, password: hashedPassword })
        });
        if (response.ok) {
            const data = await response.json();
            localStorage.setItem('auth_token', data.token);
            localStorage.setItem('user_email', data.user.email);
            await authService.performLoginSync(data.user);
            if (!data.user.isProfileCompleted) return { user: data.user, nextStep: '/complete-profile' };
            return { user: data.user, nextStep: '/feed' };
        } else {
            const err = await response.json();
            throw new Error(err.error || AuthError.WRONG_PASSWORD);
        }
    } catch (e: any) { throw new Error(e.message || "Erro de conexão com o servidor."); }
  },

  register: async (email: string, password: string, referredBy?: string) => {
    try {
        const normalizedEmail = email.toLowerCase().trim();
        const hashedPassword = await cryptoService.hashPassword(password);
        const finalReferrer = (referredBy || trackingService.getAffiliateRef() || '').toLowerCase().trim();

        localStorage.setItem('temp_register_email', normalizedEmail);
        localStorage.setItem('temp_register_pw', hashedPassword);
        if (finalReferrer) {
            localStorage.setItem('temp_referred_by', finalReferrer);
        } else {
            localStorage.removeItem('temp_referred_by');
        }
        
        await authService.sendVerificationCode(normalizedEmail);
    } catch (e: any) { throw new Error(e.message || AuthError.GENERIC); }
  },

  verifyCode: async (email: string, code: string, isResetFlow: boolean = false) => {
    const normalizedEmail = email.toLowerCase().trim();
    const sessionStr = localStorage.getItem(`verify_${normalizedEmail}`);
    const session = sessionStr ? JSON.parse(sessionStr) : null;
    
    if (!session) throw new Error(AuthError.CODE_EXPIRED);
    if (session) {
        if (Date.now() > session.expiresAt) throw new Error(AuthError.CODE_EXPIRED);
        if (session.code !== code) throw new Error(AuthError.CODE_INVALID);
    }
    
    if (!isResetFlow) {
        const passwordHash = localStorage.getItem('temp_register_pw');
        const referredBy = localStorage.getItem('temp_referred_by');
        if (!passwordHash) throw new Error("Erro de sessão. Tente registrar novamente.");
        const newUserPayload = {
            email: normalizedEmail, 
            password: passwordHash, 
            isVerified: true, 
            isProfileCompleted: false,
            referredBy: referredBy || undefined,
            profile: { name: normalizedEmail.split('@')[0].toLowerCase().replace(/[^a-z0-9]/g, ''), nickname: 'Novo Usuário', isPrivate: false }
        };
        try {
            const response = await fetch(`${API_URL}/register`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(newUserPayload)
            });
            if (!response.ok) { const data = await response.json(); throw new Error(data.error || "Falha ao criar conta."); }
            const data = await response.json();
            await authService.performLoginSync(data.user || (newUserPayload as User));
            localStorage.setItem('user_email', normalizedEmail);
            localStorage.setItem('auth_token', data.token || 'temp_token_after_reg');
            localStorage.removeItem('temp_register_email');
            localStorage.removeItem('temp_register_pw');
            localStorage.removeItem('temp_referred_by');
            trackingService.clear(); 
        } catch (e: any) { throw new Error(e.message || "Erro ao conectar ao servidor."); }
    }
    return true;
  },

  sendVerificationCode: async (email: string, type: 'register' | 'reset' = 'register') => {
    const normalizedEmail = email.toLowerCase().trim();
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    const session = { code, expiresAt: Date.now() + 15 * 60 * 1000, attempts: 0 };
    localStorage.setItem(`verify_${normalizedEmail}`, JSON.stringify(session));
    try { await emailService.sendVerificationCode(normalizedEmail, code, type); } catch (e) { console.log(`[OFFLINE/DEV] Verification Code: ${code}`); }
  },

  completeProfile: async (email: string, data: UserProfile) => {
      try {
          const normalizedEmail = email.toLowerCase().trim();
          const response = await fetch(`${API_USERS}/update`, {
              method: 'PUT',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ email: normalizedEmail, updates: { profile: data, isProfileCompleted: true } })
          });
          if (response.ok) {
              const res = await response.json();
              db.users.set(res.user);
              localStorage.setItem('cached_user_profile', JSON.stringify(res.user));
              return;
          } else throw new Error("Falha ao salvar perfil.");
      } catch (e) { throw new Error("Erro de conexão. Perfil não salvo."); }
  },

  checkUsernameAvailability: async (username: string): Promise<boolean> => {
      const cleanUsername = username.toLowerCase().trim();
      const allUsers = db.users.getAll();
      const taken = Object.values(allUsers).some(u => u.profile?.name === cleanUsername);
      if (taken) return false;
      try {
          const response = await fetch(`${API_USERS}/search?q=${cleanUsername}`);
          if (response.ok) {
              const users = await response.json();
              return !users.some((u: any) => u.profile?.name === cleanUsername);
          }
      } catch (e) { }
      return true;
  },

  getCurrentUserEmail: () => localStorage.getItem('user_email'),
  getCurrentUser: (): User | null => { const cached = localStorage.getItem('cached_user_profile'); return cached ? JSON.parse(cached) : null; },
  getAllUsers: (): User[] => { return Object.values(db.users.getAll()); },
  searchUsers: async (query: string): Promise<User[]> => {
      const cleanQuery = query.replace('@', '').toLowerCase().trim();
      try {
          const response = await fetch(`${API_USERS}/search?q=${encodeURIComponent(cleanQuery)}`);
          if (response.ok) {
              const users = await response.json();
              if (Array.isArray(users)) users.forEach((u: User) => db.users.set(u));
              return users;
          }
      } catch (e) { console.warn("Server search failed."); }
      return [];
  },
  fetchUserByHandle: async (handle: string, fallbackEmail?: string): Promise<User | undefined> => {
      const clean = handle.replace('@', '').toLowerCase().trim();
      // First try by handle
      try {
          const response = await fetch(`${API_USERS}/search?q=${clean}`);
          if (response.ok) {
              const users = await response.json();
              const found = users.find((u: any) => u.profile?.name === clean);
              if (found) { db.users.set(found); return found; }
          }
      } catch (e) { console.warn("User handle fetch failed."); }

      // If handle failed but we have a fallback email, try by email
      if (fallbackEmail) {
          try {
              const response = await fetch(`${API_USERS}/sync`); // Simple sync for now or specific by-email route if available
              if (response.ok) {
                  const data = await response.json();
                  const found = data.users?.find(u => u.email.toLowerCase() === fallbackEmail.toLowerCase());
                  if (found) { db.users.set(found); return found; }
              }
          } catch (e) { console.warn("User email fetch failed."); }
      }
      
      return authService.getUserByHandle(clean);
  },
  getUserByHandle: (handle: string): User | undefined => {
      const clean = handle.replace('@', '').toLowerCase().trim();
      const all = Object.values(db.users.getAll());
      return all.find(u => u.profile?.name === clean);
  },
  logout: () => { 
      localStorage.removeItem('user_email'); 
      localStorage.removeItem('auth_token'); 
      localStorage.removeItem('cached_user_profile'); 
      localStorage.removeItem('_fb_login_id'); 
      trackingService.hardReset(); 
  },
  updatePaymentConfig: async (config: PaymentProviderConfig) => {
      const user = authService.getCurrentUser();
      if (user) {
          if (!config.isConnected) {
              if (user.paymentConfigs) delete user.paymentConfigs[config.providerId];
              if (user.paymentConfig?.providerId === config.providerId) user.paymentConfig = undefined;
          } else {
              user.paymentConfig = config; 
              if (!user.paymentConfigs) user.paymentConfigs = {};
              user.paymentConfigs[config.providerId] = config;
          }
          db.users.set(user);
          localStorage.setItem('cached_user_profile', JSON.stringify(user));
          try { 
              await fetch(`${API_USERS}/update`, { 
                  method: 'PUT', 
                  headers: { 'Content-Type': 'application/json' }, 
                  body: JSON.stringify({ email: user.email, updates: { paymentConfig: user.paymentConfig, paymentConfigs: user.paymentConfigs } }) 
              }); 
          } catch (e) { console.error("Failed to sync payment config."); }
      }
  },
  updateNotificationSettings: (settings: NotificationSettings) => { const user = authService.getCurrentUser(); if (user) { user.notificationSettings = settings; db.users.set(user); localStorage.setItem('cached_user_profile', JSON.stringify(user)); } },
  updateSecuritySettings: (settings: SecuritySettings) => { const user = authService.getCurrentUser(); if (user) { user.securitySettings = settings; db.users.set(user); localStorage.setItem('cached_user_profile', JSON.stringify(user)); } },
  updateHeartbeat: () => { const user = authService.getCurrentUser(); if (user) { user.lastSeen = Date.now(); db.users.set(user); } },
  getUserSessions: () => [{ id: 'current', device: 'Este dispositivo', location: 'Desconhecido', timestamp: Date.now(), isActive: true }],
  revokeOtherSessions: async () => {},
  resetPassword: async (email: string, newPass: string) => { 
      const normalizedEmail = email.toLowerCase().trim();
      const hash = await cryptoService.hashPassword(newPass); 
      const user = db.users.get(normalizedEmail); 
      if (user) { user.password = hash; db.users.set(user); } 
  },
  changePassword: async (currentPass: string, newPass: string) => {
      const user = authService.getCurrentUser();
      if (!user) throw new Error("Usuário não encontrado");
      const currentHash = await cryptoService.hashPassword(currentPass);
      const userInDb = db.users.get(user.email);
      if (userInDb && userInDb.password && userInDb.password !== currentHash) throw new Error("Senha atual incorreta");
      const newHash = await cryptoService.hashPassword(newPass);
      if (userInDb) { userInDb.password = newHash; db.users.set(userInDb); }
  },
  loginWithGoogle: async (googleToken?: string, referredBy?: string): Promise<{ user: User; nextStep: string }> => {
      if (!googleToken) throw new Error("Token Google não fornecido.");
      try {
          const finalReferrer = (referredBy || trackingService.getAffiliateRef() || '').toLowerCase().trim();
          const response = await fetch(`${API_URL}/google`, { 
              method: 'POST', 
              headers: { 'Content-Type': 'application/json' }, 
              body: JSON.stringify({ googleToken, referredBy: finalReferrer || null }) 
          });
          let data; const text = await response.text();
          try { data = JSON.parse(text); } catch (e) { throw new Error(`Erro inesperado do servidor (${response.status}).`); }
          if (!response.ok) throw new Error(data.error || "Falha no login com Google");
          localStorage.setItem('auth_token', data.token);
          localStorage.setItem('user_email', data.user.email);
          await authService.performLoginSync(data.user);
          trackingService.clear();
          let nextStep = '/feed'; if (data.isNew || !data.user.isProfileCompleted) nextStep = '/complete-profile';
          return { user: data.user, nextStep };
      } catch (error: any) { throw error; }
  }
};
