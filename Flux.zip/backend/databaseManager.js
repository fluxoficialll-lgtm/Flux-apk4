
import pg from 'pg';
const { Pool } = pg;

// Configuração do Pool de Conexão
if (!process.env.DATABASE_URL) {
    console.error("❌ ERRO CRÍTICO: DATABASE_URL não definida no ambiente.");
}

const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
    connectionTimeoutMillis: 30000,
    idleTimeoutMillis: 30000,
    max: 20
});

const query = async (text, params) => {
    try {
        return await pool.query(text, params);
    } catch (error) {
        console.error(`❌ DB Query Error [${text.substring(0, 50)}...]:`, error.message);
        throw error;
    }
};

export const dbManager = {
    async init() {
        console.log("🔄 DB: Inicializando Schema e verificando conexão...");
        try {
            const shouldReset = process.env.RESET_DB === 'true'; 
            
            if (shouldReset) {
                const tables = ['users', 'groups', 'posts', 'chats', 'marketplace', 'notifications', 'relationships', 'ads', 'vip_access', 'affiliate_earnings', 'financial_transactions', 'interactions'];
                for (const table of tables) {
                    await query(`DROP TABLE IF EXISTS ${table} CASCADE`);
                }
            }

            // 1. Users
            await query(`
                CREATE TABLE IF NOT EXISTS users (
                    email TEXT PRIMARY KEY, 
                    password TEXT, 
                    data JSONB, 
                    referred_by TEXT,
                    created_at TIMESTAMP DEFAULT NOW()
                )
            `);

            // 10. Affiliate Earnings
            await query(`
                CREATE TABLE IF NOT EXISTS affiliate_earnings (
                    id SERIAL PRIMARY KEY,
                    affiliate_email TEXT,
                    seller_email TEXT,
                    amount NUMERIC(10,2),
                    sale_id TEXT,
                    data JSONB,
                    created_at TIMESTAMP DEFAULT NOW()
                )
            `);

            // 11. Financial Transactions (Audit Log)
            await query(`
                CREATE TABLE IF NOT EXISTS financial_transactions (
                    id SERIAL PRIMARY KEY,
                    user_email TEXT,
                    type TEXT, -- 'withdrawal', 'sale', 'commission'
                    amount NUMERIC(10,2),
                    status TEXT, -- 'pending', 'completed', 'failed'
                    provider_tx_id TEXT,
                    data JSONB,
                    created_at TIMESTAMP DEFAULT NOW()
                )
            `);

            await query(`CREATE TABLE IF NOT EXISTS groups (id TEXT PRIMARY KEY, creator_email TEXT, data JSONB, created_at TIMESTAMP DEFAULT NOW())`);
            await query(`CREATE TABLE IF NOT EXISTS posts (id TEXT PRIMARY KEY, author_email TEXT, data JSONB, created_at TIMESTAMP DEFAULT NOW())`);
            await query(`CREATE TABLE IF NOT EXISTS chats (id TEXT PRIMARY KEY, data JSONB, updated_at TIMESTAMP DEFAULT NOW())`);
            await query(`CREATE TABLE IF NOT EXISTS marketplace (id TEXT PRIMARY KEY, seller_email TEXT, data JSONB, created_at TIMESTAMP DEFAULT NOW())`);
            await query(`CREATE TABLE IF NOT EXISTS notifications (id SERIAL PRIMARY KEY, recipient_email TEXT, data JSONB, created_at TIMESTAMP DEFAULT NOW())`);
            await query(`CREATE TABLE IF NOT EXISTS relationships (id TEXT PRIMARY KEY, follower_email TEXT, following_username TEXT, data JSONB, created_at TIMESTAMP DEFAULT NOW())`);
            await query(`CREATE TABLE IF NOT EXISTS ads (id TEXT PRIMARY KEY, owner_email TEXT, data JSONB, created_at TIMESTAMP DEFAULT NOW())`);
            await query(`CREATE TABLE IF NOT EXISTS vip_access (id TEXT PRIMARY KEY, user_email TEXT, group_id TEXT, data JSONB, created_at TIMESTAMP DEFAULT NOW())`);
            
            // 12. Interactions (Metrics: Views, Likes, Shares)
            await query(`
                CREATE TABLE IF NOT EXISTS interactions (
                    id SERIAL PRIMARY KEY,
                    post_id TEXT NOT NULL,
                    user_email TEXT,
                    type TEXT NOT NULL, -- 'view', 'like', 'share'
                    created_at TIMESTAMP DEFAULT NOW(),
                    UNIQUE(post_id, user_email, type)
                )
            `);

            console.log("✅ DB: Todas as tabelas essenciais verificadas/criadas com sucesso.");
        } catch (e) {
            console.error("❌ DB: Falha crítica na inicialização:", e.message);
        }
    },

    async countMediaReferences(url) {
        if (!url) return 0;
        try {
            const counts = await Promise.all([
                query("SELECT COUNT(*) FROM users WHERE data->>'photoUrl' = $1", [url]),
                query("SELECT COUNT(*) FROM groups WHERE data->>'coverImage' = $1 OR data->'vipDoor'->'mediaItems' @> jsonb_build_array(jsonb_build_object('url', $1::text))", [url]),
                query("SELECT COUNT(*) FROM posts WHERE data->>'image' = $1 OR data->>'video' = $2 OR data->'images' @> jsonb_build_array($3::text)", [url, url, url]),
                query("SELECT COUNT(*) FROM marketplace WHERE data->>'image' = $1 OR data->>'video' = $2 OR data->'images' @> jsonb_build_array($3::text)", [url, url, url]),
                query("SELECT COUNT(*) FROM chats WHERE EXISTS (SELECT 1 FROM jsonb_array_elements(data->'messages') AS msg WHERE msg->>'mediaUrl' = $1)", [url])
            ]);

            return counts.reduce((acc, res) => acc + parseInt(res.rows[0].count), 0);
        } catch (e) {
            console.error("Error counting media references:", e);
            return 1;
        }
    },

    users: {
        async findByEmail(email) {
            try {
                if (!email) return null;
                const normalizedEmail = email.toLowerCase().trim();
                const res = await query('SELECT * FROM users WHERE email = $1', [normalizedEmail]);
                if (res.rows.length > 0) {
                    const row = res.rows[0];
                    let userData = typeof row.data === 'string' ? JSON.parse(row.data) : row.data;
                    return { ...userData, password: row.password, email: row.email, referredBy: row.referred_by }; 
                }
                return null;
            } catch (e) { throw e; }
        },
        async create(user) {
            try {
                const normalizedEmail = user.email.toLowerCase().trim();
                const { password, referredBy, ...userData } = user;
                userData.email = normalizedEmail;
                const normalizedReferredBy = (referredBy || '').toLowerCase().trim() || null;
                await query(
                    `INSERT INTO users (email, password, data, referred_by) 
                     VALUES ($1, $2, $3, $4) 
                     ON CONFLICT (email) 
                     DO UPDATE SET 
                        password = EXCLUDED.password, 
                        data = EXCLUDED.data`,
                    [normalizedEmail, password, JSON.stringify(userData), normalizedReferredBy]
                );
                return true;
            } catch (e) { throw e; }
        },
        async update(user) {
            try {
                const normalizedEmail = user.email.toLowerCase().trim();
                const { password, referredBy, ...userData } = user;
                userData.email = normalizedEmail;
                if (password) {
                    await query(`UPDATE users SET password = $1, data = $2 WHERE email = $3`, [password, JSON.stringify(userData), normalizedEmail]);
                } else {
                    await query(`UPDATE users SET data = $1 WHERE email = $2`, [JSON.stringify(userData), normalizedEmail]);
                }
                return true;
            } catch (e) { throw e; }
        },
        async getAll() {
            try {
                const res = await query('SELECT * FROM users LIMIT 2000', []);
                return res.rows.map(row => {
                    let data = typeof row.data === 'string' ? JSON.parse(row.data) : row.data;
                    return { ...data, email: row.email, referredBy: row.referred_by };
                });
            } catch (e) { return []; }
        }
    },

    interactions: {
        async record(postId, userEmail, type) {
            try {
                const normalizedEmail = userEmail ? userEmail.toLowerCase().trim() : null;
                await query(`
                    INSERT INTO interactions (post_id, user_email, type)
                    VALUES ($1, $2, $3)
                    ON CONFLICT (post_id, user_email, type) DO NOTHING
                `, [postId, normalizedEmail, type]);
                const countRes = await query(`SELECT COUNT(*) FROM interactions WHERE post_id = $1 AND type = $2`, [postId, type]);
                const count = parseInt(countRes.rows[0].count);
                const postRes = await query(`SELECT author_email, data FROM posts WHERE id = $1`, [postId]);
                if (postRes.rows.length > 0) {
                    const row = postRes.rows[0];
                    let postData = typeof row.data === 'string' ? JSON.parse(row.data) : row.data;
                    if (type === 'view') postData.views = count;
                    if (type === 'like') {
                        postData.likes = count;
                        const emailsRes = await query(`SELECT user_email FROM interactions WHERE post_id = $1 AND type = 'like'`, [postId]);
                        postData.likedBy = emailsRes.rows.map(r => r.user_email).filter(Boolean);
                    }
                    if (type === 'share') postData.shares = count;
                    await query(`UPDATE posts SET data = $1 WHERE id = $2`, [JSON.stringify(postData), postId]);
                }
                return true;
            } catch (e) { return false; }
        },
        async remove(postId, userEmail, type) {
            try {
                const normalizedEmail = userEmail ? userEmail.toLowerCase().trim() : null;
                await query(`DELETE FROM interactions WHERE post_id = $1 AND user_email = $2 AND type = $3`, [postId, normalizedEmail, type]);
                const countRes = await query(`SELECT COUNT(*) FROM interactions WHERE post_id = $1 AND type = $2`, [postId, type]);
                const count = parseInt(countRes.rows[0].count);
                const postRes = await query(`SELECT author_email, data FROM posts WHERE id = $1`, [postId]);
                if (postRes.rows.length > 0) {
                    const row = postRes.rows[0];
                    let postData = typeof row.data === 'string' ? JSON.parse(row.data) : row.data;
                    if (type === 'like') {
                        postData.likes = count;
                        const emailsRes = await query(`SELECT user_email FROM interactions WHERE post_id = $1 AND type = 'like'`, [postId]);
                        postData.likedBy = emailsRes.rows.map(r => r.user_email).filter(Boolean);
                    }
                    await query(`UPDATE posts SET data = $1 WHERE id = $2`, [JSON.stringify(postData), postId]);
                }
                return true;
            } catch (e) { return false; }
        }
    },

    posts: {
        async create(post) { 
            try { 
                const authorEmail = post.authorEmail ? post.authorEmail.toLowerCase().trim() : (post.username && post.username.includes('@') ? post.username.toLowerCase().trim() : 'unknown'); 
                await query('INSERT INTO posts (id, author_email, data) VALUES ($1, $2, $3) ON CONFLICT (id) DO UPDATE SET data = $3, author_email = $2', [post.id, authorEmail, JSON.stringify(post)]); 
                return true; 
            } catch (e) { throw e; } 
        },
        async getById(id) {
            try {
                const res = await query('SELECT author_email, data FROM posts WHERE id = $1', [id]);
                if (res.rows.length > 0) {
                    const row = res.rows[0];
                    let data = typeof row.data === 'string' ? JSON.parse(row.data) : row.data;
                    return { ...data, authorEmail: row.author_email };
                }
                return null;
            } catch (e) { throw e; }
        },
        async list(limit = 50, cursor = null) { 
            try { 
                let sql = 'SELECT author_email, data FROM posts';
                let params = [limit];
                if (cursor && cursor !== 'null' && cursor !== 'undefined' && cursor !== '') {
                    const numericCursor = Number(cursor);
                    const date = !isNaN(numericCursor) ? new Date(numericCursor) : new Date(cursor);
                    if (!isNaN(date.getTime())) {
                        sql += ' WHERE created_at < $2 ORDER BY created_at DESC LIMIT $1';
                        params.push(date);
                    } else { sql += ' ORDER BY created_at DESC LIMIT $1'; }
                } else { sql += ' ORDER BY created_at DESC LIMIT $1'; }
                const res = await query(sql, params); 
                return res.rows.map(r => {
                    let data = typeof r.data === 'string' ? JSON.parse(r.data) : r.data;
                    return { ...data, authorEmail: r.author_email };
                }); 
            } catch (e) { return []; } 
        },
        async delete(id) { try { await query('DELETE FROM posts WHERE id = $1', [id]); return true; } catch (e) { throw e; } }
    },

    affiliates: {
        async recordEarning(affiliateEmail, sellerEmail, amount, saleId, extraData = {}) {
            try {
                const normalizedAff = affiliateEmail.toLowerCase().trim();
                const normalizedSeller = sellerEmail.toLowerCase().trim();
                await query('INSERT INTO affiliate_earnings (affiliate_email, seller_email, amount, sale_id, data) VALUES ($1, $2, $3, $4, $5)', [normalizedAff, normalizedSeller, amount, saleId, JSON.stringify(extraData)]);
                return true;
            } catch (e) { return false; }
        },
        async getStats(affiliateEmail) {
            try {
                const normalizedAff = affiliateEmail.toLowerCase().trim();
                const sellersRes = await query(`
                    SELECT u.email, COUNT(ae.id) as sales_count, COALESCE(SUM(ae.amount), 0) as total_generated
                    FROM users u
                    LEFT JOIN affiliate_earnings ae ON TRIM(LOWER(u.email)) = TRIM(LOWER(ae.seller_email)) AND TRIM(LOWER(ae.affiliate_email)) = $1
                    WHERE TRIM(LOWER(u.referred_by)) = $1
                    GROUP BY u.email
                `, [normalizedAff]);
                const sellersList = sellersRes.rows.map(row => ({ email: row.email, salesCount: parseInt(row.sales_count), totalGenerated: parseFloat(row.total_generated) }));
                const earningsRes = await query('SELECT * FROM affiliate_earnings WHERE TRIM(LOWER(affiliate_email)) = $1 ORDER BY created_at DESC', [normalizedAff]);
                const totalEarned = earningsRes.rows.reduce((acc, curr) => acc + parseFloat(curr.amount), 0);
                return { earnings: earningsRes.rows, sellersList, totalEarned };
            } catch (e) { throw e; }
        },
        async getEarningByPeriod(affiliateEmail, startTimestamp) {
            try {
                const normalizedAff = affiliateEmail.toLowerCase().trim();
                const res = await query('SELECT SUM(amount) as total FROM affiliate_earnings WHERE TRIM(LOWER(affiliate_email)) = $1 AND created_at >= to_timestamp($2)', [normalizedAff, startTimestamp / 1000]);
                return parseFloat(res.rows[0].total || 0);
            } catch (e) { return 0; }
        }
    },

    transactions: {
        async record(user_email, type, amount, status, provider_tx_id, data = {}) {
            try {
                const normalizedEmail = user_email.toLowerCase().trim();
                await query('INSERT INTO financial_transactions (user_email, type, amount, status, provider_tx_id, data) VALUES ($1, $2, $3, $4, $5, $6)', [normalizedEmail, type, amount, status, provider_tx_id, JSON.stringify(data)]);
                return true;
            } catch (e) { return false; }
        },
        async list(user_email) {
            try {
                const normalizedEmail = user_email.toLowerCase().trim();
                const res = await query('SELECT * FROM financial_transactions WHERE TRIM(LOWER(user_email)) = $1 ORDER BY created_at DESC', [normalizedEmail]);
                return res.rows;
            } catch (e) { return []; }
        }
    },

    groups: {
        async list() { try { const res = await query('SELECT data FROM groups ORDER BY created_at DESC LIMIT 100', []); return res.rows.map(r => typeof r.data === 'string' ? JSON.parse(r.data) : r.data); } catch (e) { return []; } },
        async listForUser(email) { try { const normalizedEmail = email.toLowerCase().trim(); const text = `SELECT data FROM groups WHERE TRIM(LOWER(creator_email)) = $1 OR (data::jsonb->'members') @> $2::jsonb ORDER BY created_at DESC`; const res = await query(text, [normalizedEmail, JSON.stringify([normalizedEmail])]); return res.rows.map(r => typeof r.data === 'string' ? JSON.parse(r.data) : r.data); } catch (e) { return []; } },
        async getById(id) { try { const res = await query('SELECT data FROM groups WHERE id = $1', [id]); return res.rows[0] ? (typeof res.rows[0].data === 'string' ? JSON.parse(res.rows[0].data) : res.rows[0].data) : null; } catch (e) { return null; } },
        async create(group) { try { const creator = group.creatorEmail ? group.creatorEmail.toLowerCase().trim() : null; await query('INSERT INTO groups (id, creator_email, data) VALUES ($1, $2, $3) ON CONFLICT (id) DO UPDATE SET data = $3, creator_email = $2', [group.id, creator, JSON.stringify(group)]); return true; } catch (e) { throw e; } },
        async delete(id) { try { await query('DELETE FROM groups WHERE id = $1', [id]); return true; } catch (e) { throw e; } }
    },
    vipAccess: {
        async get(userId, groupId) { try { const normalizedId = userId.toLowerCase().trim(); const id = `${normalizedId}_${groupId}`; const res = await query('SELECT data FROM vip_access WHERE id = $1', [id]); return res.rows[0] ? (typeof res.rows[0].data === 'string' ? JSON.parse(res.rows[0].data) : res.rows[0].data) : null; } catch (e) { return null; } },
        async grant(access) { try { const normalizedId = access.userId.toLowerCase().trim(); const id = `${normalizedId}_${access.groupId}`; await query('INSERT INTO vip_access (id, user_email, group_id, data) VALUES ($1, $2, $3, $4) ON CONFLICT (id) DO UPDATE SET data = $4', [id, normalizedId, access.groupId, JSON.stringify(access)]); return true; } catch (e) { throw e; } }
    },
    marketplace: {
        async create(item) { try { const seller = item.sellerId ? item.sellerId.toLowerCase().trim() : null; await query('INSERT INTO marketplace (id, seller_email, data) VALUES ($1, $2, $3) ON CONFLICT (id) DO UPDATE SET data = $3', [item.id, seller, JSON.stringify(item)]); return true; } catch (e) { throw e; } },
        async getById(id) {
            try {
                const res = await query('SELECT seller_email, data FROM marketplace WHERE id = $1', [id]);
                if (res.rows.length > 0) {
                    const row = res.rows[0];
                    let data = typeof row.data === 'string' ? JSON.parse(row.data) : row.data;
                    return { ...data, sellerId: row.seller_email };
                }
                return null;
            } catch (e) { throw e; }
        },
        async list() { try { const res = await query('SELECT seller_email, data FROM marketplace ORDER BY created_at DESC LIMIT 100', []); return res.rows.map(r => { let d = typeof r.data === 'string' ? JSON.parse(r.data) : r.data; return { ...d, sellerId: r.seller_email }; }); } catch (e) { return []; } },
        async delete(id) { try { await query('DELETE FROM marketplace WHERE id = $1', [id]); return true; } catch (e) { throw e; } }
    },
    ads: {
        async create(ad) { try { const owner = ad.ownerEmail ? ad.ownerEmail.toLowerCase().trim() : null; await query('INSERT INTO ads (id, owner_email, data) VALUES ($1, $2, $3) ON CONFLICT (id) DO UPDATE SET data = $3', [ad.id, owner, JSON.stringify(ad)]); return true; } catch (e) { throw e; } },
        async list() { try { const res = await query('SELECT data FROM ads ORDER BY created_at DESC LIMIT 50', []); return res.rows.map(r => typeof r.data === 'string' ? JSON.parse(r.data) : r.data); } catch (e) { return []; } },
        async delete(id) { try { await query('DELETE FROM ads WHERE id = $1', [id]); return true; } catch (e) { throw e; } }
    },
    relationships: {
        async create(rel) { try { const follower = rel.followerEmail.toLowerCase().trim(); const id = `${follower}_${rel.followingUsername}`; await query('INSERT INTO relationships (id, follower_email, following_username, data) VALUES ($1, $2, $3, $4) ON CONFLICT (id) DO UPDATE SET data = $4', [id, follower, rel.followingUsername, JSON.stringify(rel)]); return true; } catch (e) { throw e; } },
        async delete(followerEmail, followingUsername) { try { const follower = followerEmail.toLowerCase().trim(); const id = `${follower}_${followingUsername}`; await query('DELETE FROM relationships WHERE id = $1', [id]); return true; } catch (e) { throw e; } },
        async list() { try { const res = await query('SELECT data FROM relationships LIMIT 1000', []); return res.rows.map(r => typeof r.data === 'string' ? JSON.parse(r.data) : r.data); } catch (e) { return []; } },
        async getTopCreators() {
            try {
                const sql = `
                    SELECT u.email, u.data, COUNT(r.id) as follower_count
                    FROM users u
                    LEFT JOIN relationships r ON u.data->>'name' = r.following_username
                    WHERE r.data->>'status' = 'accepted' OR r.id IS NULL
                    GROUP BY u.email
                    ORDER BY follower_count DESC
                    LIMIT 50
                `;
                const res = await query(sql, []);
                return res.rows.map(row => {
                    let userData = typeof row.data === 'string' ? JSON.parse(row.data) : row.data;
                    return { ...userData, email: row.email, followerCount: parseInt(row.follower_count) };
                });
            } catch (e) { return []; }
        }
    },
    chats: {
        async get(id) { try { const res = await query('SELECT data FROM chats WHERE id = $1', [id]); return res.rows[0] ? (typeof res.rows[0].data === 'string' ? JSON.parse(res.rows[0].data) : res.rows[0].data) : null; } catch(e) { return null; } },
        async save(chat) { try { await query('INSERT INTO chats (id, data) VALUES ($1, $2) ON CONFLICT (id) DO UPDATE SET data = $2, updated_at = NOW()', [chat.id, JSON.stringify(chat)]); return true; } catch(e) { throw e; } },
        async listForUser(email) {
            try {
                const normalizedEmail = email.toLowerCase().trim();
                const res = await query("SELECT data FROM chats WHERE id LIKE $1", [`%${normalizedEmail}%`]);
                return res.rows.map(r => typeof r.data === 'string' ? JSON.parse(r.data) : r.data);
            } catch (e) { return []; }
        }
    },
    notifications: {
        async create(notif) { try { const recipient = notif.recipientEmail.toLowerCase().trim(); await query('INSERT INTO notifications (recipient_email, data) VALUES ($1, $2)', [recipient, JSON.stringify(notif)]); return true; } catch (e) { throw e; } },
        async list(email) { try { const normalizedEmail = email.toLowerCase().trim(); const res = await query('SELECT data FROM notifications WHERE TRIM(LOWER(recipient_email)) = $1 ORDER BY created_at DESC LIMIT 50', [normalizedEmail]); return res.rows.map(r => typeof r.data === 'string' ? JSON.parse(r.data) : r.data); } catch (e) { return []; } }
    }
};
