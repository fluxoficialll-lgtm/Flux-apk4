
import path from 'path';
import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default defineConfig(({ mode }) => {
    const env = loadEnv(mode, __dirname, '');
    
    // Captura valores com fallback
    const googleClientId = process.env.GOOGLE_CLIENT_ID || env.GOOGLE_CLIENT_ID || "";
    const pixelId = process.env.VITE_PIXEL_ID || env.VITE_PIXEL_ID || "";
    const apiBaseUrl = process.env.VITE_API_BASE_URL || env.VITE_API_BASE_URL || "";
    const apiKey = process.env.GEMINI_API_KEY || env.GEMINI_API_KEY || env.API_KEY || "";

    // Base relativa para produção (Render)
    const base = apiBaseUrl ? '/' : './';

    return {
      base: base,
      server: {
        port: 5173,
        host: '0.0.0.0',
        proxy: {
          '/api': {
            target: 'http://127.0.0.1:3000', // Alterado de localhost para IP explícito
            changeOrigin: true,
            secure: false
          }
        }
      },
      build: {
        outDir: 'dist',
        assetsDir: 'assets',
        sourcemap: false,
        minify: 'terser',
        terserOptions: {
            compress: {
                drop_console: true,
                drop_debugger: true
            }
        }
      },
      plugins: [react()],
      define: {
        // CORREÇÃO: Removido 'process.env': {} para evitar apagar variáveis globais.
        // Injetamos apenas as variáveis específicas necessárias.
        
        'process.env.GOOGLE_CLIENT_ID': JSON.stringify(googleClientId),
        'import.meta.env.VITE_GOOGLE_CLIENT_ID': JSON.stringify(googleClientId),
        
        'process.env.VITE_API_BASE_URL': JSON.stringify(apiBaseUrl),
        'import.meta.env.VITE_API_BASE_URL': JSON.stringify(apiBaseUrl),
        
        'process.env.VITE_PIXEL_ID': JSON.stringify(pixelId),
        'import.meta.env.VITE_PIXEL_ID': JSON.stringify(pixelId),

        'process.env.API_KEY': JSON.stringify(apiKey),
      },
      resolve: {
        alias: {
          '@': path.resolve(__dirname),
        }
      }
    };
});
