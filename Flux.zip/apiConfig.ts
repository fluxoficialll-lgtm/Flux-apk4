
import { Capacitor } from '@capacitor/core';

/**
 * Configuração Central da API
 * 
 * FIX CRÍTICO: Remoção de dependência direta de 'process.env' sem verificação.
 * Utilizamos import.meta.env que é o padrão nativo do Vite para evitar ReferenceError.
 */

const getBaseUrl = () => {
    let envUrl = '';

    // 1. Tenta ler do padrão Vite (Mais seguro e correto)
    try {
        // @ts-ignore
        if (typeof import.meta !== 'undefined' && import.meta.env) {
            // @ts-ignore
            envUrl = import.meta.env.VITE_API_BASE_URL;
        }
    } catch (e) {
        console.warn("Erro ao ler import.meta.env");
    }

    // 2. Fallback seguro para process.env (caso o define plugin injete)
    if (!envUrl) {
        try {
            // @ts-ignore
            if (typeof process !== 'undefined' && process.env) {
                // @ts-ignore
                envUrl = process.env.API_BASE_URL;
            }
        } catch (e) {
            // Ignora silenciosamente para não travar a tela
        }
    }
    
    // Detecção de ambiente nativo (APK Android/iOS)
    const isNative = Capacitor.isNativePlatform();

    if (isNative) {
        if (!envUrl) {
            console.error("🚨 ERRO CRÍTICO (APK): URL da API não definida. Usando localhost do emulador.");
            return 'http://10.0.2.2:3000'; 
        }
        return envUrl.endsWith('/') ? envUrl.slice(0, -1) : envUrl;
    }

    // Na Web (Render/Navegador)
    if (envUrl) {
        return envUrl.endsWith('/') ? envUrl.slice(0, -1) : envUrl;
    }
    
    // Padrão para Render: Vazio (caminho relativo)
    return '';
};

export const API_BASE = getBaseUrl();

// Debug seguro (não trava se console falhar)
try {
    console.log(`🚀 [Flux API] Iniciado. Base: "${API_BASE || 'Relativa'}"`);
} catch (e) {}
